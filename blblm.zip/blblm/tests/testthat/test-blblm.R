test_that("blblm coef works", {
  blb.lm <- blblm::blblm(Wt ~ Dose * conc, m = floor(sqrt(nrow(Theoph))), data = Theoph)
  expect_equal(length(blb.lm), 2)
})
