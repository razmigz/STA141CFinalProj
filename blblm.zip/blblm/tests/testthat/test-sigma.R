test_that("multiplication works", {
  blb.lm <- blblm(Wt ~  Dose * conc, data = Theoph, m = floor(sqrt(nrow(Theoph))))
  test.case <- 0.8517126
  expect_equal(round(test.case, 7), round(sigma(blb.lm), 7))
})
