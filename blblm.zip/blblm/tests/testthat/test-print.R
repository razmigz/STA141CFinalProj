test_that("multiplication works", {
  blb.lm <- blblm(Wt ~  Dose * conc, data = Theoph, m = floor(sqrt(nrow(Theoph))))
  test.case <- cat("blblm model:", capture.output(blb.lm$formula))
  expect_equal(cat("blblm model:","Wt ~ Dose * Conc"), test.case)
})
