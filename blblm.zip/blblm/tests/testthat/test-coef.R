test_that("blblm coef works", {
  blb.lm <- blblm::blblm(Wt ~ Dose * conc, m = floor(sqrt(nrow(Theoph))), data = Theoph)
  tester <- c(135.5084642, -14.2943125, -1.0015405, 0.2394969)
  names(tester) <- c("(Intercept)", "Dose", "conc", "Dose:conc")
  expect_equal(round(coef(blb.lm), 7), tester)
})