test_that("blblm confint works", {
  blb.lm <- blblm::blblm(Wt ~ Dose * conc, m = floor(sqrt(nrow(Theoph))), data = Theoph)
  test.case <- matrix(data = round( c(-14.8972115,  -1.5263127, -13.7174297, -0.4679980), 7), ncol = 2, nrow = 2)
  rownames(test.case) <- c("Dose", "conc")
  colnames(test.case) <- c("2.5%", "97.5%")
  expect_equal(test.case, round(confint(blb.lm, c("Dose", "conc")), 7))
})
