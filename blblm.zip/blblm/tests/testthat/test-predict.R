test_that("blblm prediction works", {
  blb.lm <- blblm::blblm(Wt ~ Dose * conc, m = floor(sqrt(nrow(Theoph))), data = Theoph)
  tester <- round(c(79.69314, 78.26588), 5)
  names(tester) <- c("1", "2")
  expect_equal(round(predict(blb.lm, data.frame(Dose = c(3.9, 4.0), conc = c(1, 1.5), Wt = c(80, 85))), 5), tester)
})
