#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

//'Get a weighted least squares regression
//'
//'
//' @param X data matrix containing predictor variables
//' @param y vector of a response variable
//' @param w vector of weightws
//' @export
// [[Rcpp::export]]
Rcpp::List w_fastLm(const arma::mat& X, const arma::colvec& y, const arma::colvec& w) {
  int n = X.n_rows, k = X.n_cols;

  arma::colvec coef = arma::inv(arma::trans(X)* arma::diagmat(w)*X) * arma::trans(X) * arma::diagmat(w) * y;
  arma::colvec res  = y - X*coef;           // residuals

  // std.errors of coefficients
  double s2 = std::inner_product(res.begin(), res.end(), res.begin(), 0.0)/(n - k);

  arma::colvec std_err = arma::sqrt(s2 * arma::diagvec(arma::pinv(arma::trans(X)*X)));

  return Rcpp::List::create(Rcpp::Named("coefficients") = coef,
                            Rcpp::Named("stderr")       = std_err,
                            Rcpp::Named("df.residual")  = n - k);
}