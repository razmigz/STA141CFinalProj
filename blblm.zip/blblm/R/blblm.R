#' @aliases blblm-package
#' @import purrr
#' @import stats
#' @importFrom magrittr %>%
#' @import parallel
#' @import furrr
#' @import future
#' @details
#' Linear Regression with Bag of Little Bootstraps
"_PACKAGE"


## quiets concerns of R CMD check re: the .'s that appear in pipelines
# from https://github.com/jennybc/googlesheets/blob/master/R/googlesheets.R
utils::globalVariables(c("."))


#' Run BLB for a Linear Model
#'
#' From a given formula with a number of subsamples (m) and times to resample (B) with Bootstrapping, generate a BLB Linear Model with the option to parallelize
#'
#' @param formula formula
#'
#' @param data a data.frame object containing the variables to be in the model
#' @param m integer - number of subsample groups
#' @param B integer - the number of bootstrap samples to generate
#' @param parallelize logical - whether or not to use parallelization
#' @param n_workers integer - the number of workers to be used for parallelization
#' @param use_cpp logical - whether or not implement the c++ version
#' @param seed integer - seed for randomization
#'
#' @export
#' @examples blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, parallelize = FALSE, n_workers = detectCores())
blblm <- function(formula, data, m = 10, B = 5000, parallelize = FALSE, n_workers = detectCores(), seed = 1, use_cpp = FALSE) {
  set.seed(seed)
  data_list <- split_data(data, m)
  #use non-parallelized version:
  if(use_cpp){
    estimates <- map(
      data_list,
      ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B, use_cpp = TRUE))
  }  else if(parallelize == FALSE){
  estimates <- map(
    data_list,
    ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B))
  } else{
  #parallelized version:
  #ignore warnings
  suppressWarnings(plan(multiprocess, workers = n_workers))
  options(future.rng.onMisuse = "ignore")
  estimates <- future_map(
    data_list,
    ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B))
}
  res <- list(estimates = estimates, formula = formula)
  class(res) <- "blblm"
  invisible(res)
}

#' split data into m parts of approximated equal sizes
#'
#' @param data a data frame object
#' @param m integer - the number of splits to make
split_data <- function(data, m) {
  idx <- sample.int(m, nrow(data), replace = TRUE)
  data %>% split(idx)
}


#' compute the estimates
#'
#' @param formula a formula object
#' @param data  a data.frame object
#' @param n an integer - number of subsamples
#' @param B an integer - the number of times to bootstrap
#' @param use_cpp logical - whether or not implement the c++ version
lm_each_subsample <- function(formula, data, n, B, use_cpp = FALSE) {
  # drop the original closure of formula,
  # otherwise the formula will pick a wrong variable from the global scope.
  environment(formula) <- environment()
  m <- model.frame(formula, data)
  X <- model.matrix(formula, m)
  y <- model.response(m)
  if(use_cpp){
    replicate(B, fastLm(X, y, n), simplify = FALSE)
  } else{
    replicate(B, lm1(X, y, n), simplify = FALSE)
  }

}


#' compute the regression estimates for a blb dataset
#'
#' @param X explanatory variables
#' @param y response variable
#' @param n integer - number of observations in X
lm1 <- function(X, y, n) {
  freqs <- as.vector(rmultinom(1, n, rep(1, nrow(X))))
  fit <- lm.wfit(X, y, freqs)
  list(coef = blbcoef(fit), sigma = blbsigma(fit))
}

fastLm <- function(X, y, n){
  freqs <- as.vector(rmultinom(1, n, rep(1, nrow(X))))
  fit <- w_fastLm(X, y, freqs)
  list(coef = blbcoef(fit), sigma = blbsigma(fit))
}

#' compute the coefficients from fit
#'
#' @param fit blblm model fit
blbcoef <- function(fit) {
  coef(fit)
}


#' compute sigma from fit
#'
#' @param fit blblm model fit
blbsigma <- function(fit) {
  p <- fit$rank
  e <- fit$residuals
  w <- fit$weights
  sqrt(sum(w * (e^2)) / (sum(w) - p))
}

#' Print model
#'
#' Print model used to create BLB Linear Model
#'
#' @param x blblm object
#'
#' @param ... additional arguments to be passed
#'
#' @export
#' @examples
#' model.fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, parallelize = FALSE, n_workers = detectCores())
#' print(model.fit)
#'
#' @method print blblm
print.blblm <- function(x, ...) {
  cat("blblm model:", capture.output(x$formula))
  cat("\n")
}


#' Compute SSE of a BLB Linear Model
#'
#' Compute the Sume of Squared Errors from a given linear model creating using BLB to estimate error
#' @param object blblm object
#'
#' @param confidence logical - give a confidence interval or do not
#' @param level double between 0 and 1
#' @param ... additional arguments to be passed
#'
#' @export
#' @method sigma blblm
#' @examples model.fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, parallelize = FALSE, n_workers = detectCores())
#' sigma(model.fit)
sigma.blblm <- function(object, confidence = FALSE, level = 0.95, ...) {
  est <- object$estimates
  sigma <- mean(map_dbl(est, ~ mean(map_dbl(., "sigma"))))
  if (confidence) {
    #define alpha as the probability of a type I error/1-alpha
    alpha <- 1 - level
    limits <- est %>%
      map_mean(~ quantile(map_dbl(., "sigma"), c(alpha / 2, 1 - alpha / 2))) %>%
      set_names(NULL)
    return(c(sigma = sigma, lwr = limits[1], upr = limits[2]))
  } else {
    return(sigma)
  }
}

#' Coefficients of a BLB Linear Model
#'
#' Get the coefficients of each parameter in a BLB Linear Model object
#'
#' @param object a blblm object
#'
#' @param ... additional arguments to be passed
#'
#' @export
#' @method coef blblm
#'
#' @examples blb.lm <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, parallelize = FALSE, n_workers = detectCores())
#' coef(blb.lm)
coef.blblm <- function(object, ...) {
  est <- object$estimates
  map_mean(est, ~ map_cbind(., "coef") %>% rowMeans())
}


#' @param object blblm object
#'
#' @param parm
#' @param level double between 0 and 1
#' @param ... additional arguments to be passed
#'
#' @export
#' @method confint blblm
#'
#' @examples blb.lm <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, parallelize = FALSE, n_workers = detectCores())
#' confint(blb.lm)
confint.blblm <- function(object, parm = NULL, level = 0.95, ...) {
  if (is.null(parm)) {
    parm <- attr(terms(object$formula), "term.labels")
  }
  alpha <- 1 - level
  est <- object$estimates
  out <- map_rbind(parm, function(p) {
    map_mean(est, ~ map_dbl(., list("coef", p)) %>% quantile(c(alpha / 2, 1 - alpha / 2)))
  })
  if (is.vector(out)) {
    out <- as.matrix(t(out))
  }
  dimnames(out)[[1]] <- parm
  out
}

#' @export
#' @method predict blblm
predict.blblm <- function(object, new_data, confidence = FALSE, level = 0.95, ...) {
  est <- object$estimates
  X <- model.matrix(reformulate(attr(terms(object$formula), "term.labels")), new_data)
  if (confidence) {
    map_mean(est, ~ map_cbind(., ~ X %*% .$coef) %>%
      apply(1, mean_lwr_upr, level = level) %>%
      t())
  } else {
    map_mean(est, ~ map_cbind(., ~ X %*% .$coef) %>% rowMeans())
  }
}

mean_lwr_upr <- function(x, level = 0.95) {
  alpha <- 1 - level
  c(fit = mean(x), quantile(x, c(alpha / 2, 1 - alpha / 2)) %>% set_names(c("lwr", "upr")))
}

map_mean <- function(.x, .f, ...) {
  (map(.x, .f, ...) %>% reduce(`+`)) / length(.x)
}

map_cbind <- function(.x, .f, ...) {
  map(.x, .f, ...) %>% reduce(cbind)
}

map_rbind <- function(.x, .f, ...) {
  map(.x, .f, ...) %>% reduce(rbind)
}

